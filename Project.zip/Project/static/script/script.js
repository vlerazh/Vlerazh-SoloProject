$('#register_form').hide(function(){
    $('#btn1').click(function(){
        $('#restaurant_list').hide();
        $('#register_form').show(); 
            
    });
});
$('#restaurant_list').hide(function(){
    $('#btn2').click(function(){
        $('#register_form').hide();
        $('#restaurant_list').show();
    });
});
       
  
        
    
