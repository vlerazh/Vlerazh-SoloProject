from flask import Flask, render_template,redirect,request,session,flash
from myconnection import connectToMySQL
from flask_bcrypt import Bcrypt 
import re

app = Flask(__name__)
bcrypt = Bcrypt(app)
app.secret_key="shh"
EMAIL_REGEX= re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route("/")
def landing():
    return render_template("main.html")

@app.route("/on_register")
def on_register():
    return render_template("register.html")

@app.route("/register_user", methods=['POST'])
def register_user():
    val=True
    if len(request.form['fname'])<1:
        val=False
        flash("Fist name shoudn't be empty")
    if len(request.form['lname'])<1:
        val=False
        flash("Last name shoudn't be empty")
    if not EMAIL_REGEX.match(request.form['email']):
        val=False
        flash("Invalid email address")
    if len(request.form['pw'])<5:
        val=False
        flash("Password should be at least 5 characters")
    if  not request.form['confirmPw'] == request.form['pw']:
        val=False
        flash("Passwords doesn't match!")
    
    if val:
        mysql=connectToMySQL('restaurants')
        query="INSERT INTO user(firstname,lastname,email,password,created_at,updated_at) VALUES(%(fn)s,%(ln)s,%(email)s,%(pw)s,NOW(),NOW())"
        data={
            'fn':request.form['fname'],
            'ln':request.form['lname'],
            'email':request.form['email'],
            'pw':bcrypt.generate_password_hash(request.form['pw'])
        }
        users=mysql.query_db(query,data)
        if users:
            session['user_id']=users
        return redirect("/on_login")

@app.route("/on_login")
def on_login():
    return render_template("login.html")

@app.route("/login", methods=['POST'])
def login():
    valid=True
    if len(request.form['email'])<1:
        valid=False
        flash("Email cannot be blank")
        
    mysql = connectToMySQL('restaurants')
    query = "SELECT * from user where email = %(em)s"
    data = {
        "em": request.form['email']
    }
    result = mysql.query_db(query,data)

    if result:
        user_data= result[0]
        print(user_data)
        if bcrypt.check_password_hash(user_data['password'],request.form['pw']):
            session['user_id']=user_data['user_id']
            print(session['user_id'])
            return redirect("/choose")
        else:
            valid=False
            flash("Password is not correct")
    else:
        valid=False
        flash("Email is incorrect")
    if not valid:
        return redirect("/on_login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/choose")
def choose():
    #get restaurants
    mysql=connectToMySQL('restaurants')
    query="SELECT * FROM restaurant"
    restaurants=mysql.query_db(query)
    return render_template("choose.html",restaurants=restaurants)

@app.route("/register_restaurant", methods=['POST'])
def register_restaurant():

    is_valid=True
    if len(request.form['name'])<1:
        val=False
        flash("Name field shoudn't be empty")
    if len(request.form['location'])<1:
        val=False
        flash("Location field shoudn't be empty")
    if int(request.form['nr_tables']) < 5:
        val = False
        flash("You should have more than 5 tables")
    
    if is_valid:
        mysql=connectToMySQL('restaurants')
        query="INSERT INTO restaurant(name,location,table_nr,description,created_at,updated_at) VALUES(%(name)s,%(location)s,%(nr_table)s,%(dsc)s,NOW(),NOW())"
        data = {
            'name':request.form['name'],
            'location':request.form['location'],
            'nr_table':request.form['nr_tables'],
            'dsc':request.form['description']
        }
        mysql.query_db(query,data)

        #get restaurants
        mysql=connectToMySQL('restaurants')
        query="SELECT * FROM restaurant"
        restaurants=mysql.query_db(query)
        return render_template("choose.html",restaurants=restaurants)

@app.route("/details/<restaurant_id>")
def details(restaurant_id):
    mysql=connectToMySQL('restaurants')
    query="SELECT restaurant_id,restaurant.name,restaurant.location,restaurant.table_nr,restaurant.description FROM restaurant WHERE restaurant.restaurant_id = %(r_id)s"
    data={
        'r_id':restaurant_id
    }
    restaurant=mysql.query_db(query,data)
    print(restaurant)
    if restaurant:
        restaurant_data=restaurant[0]
        session['restaurant_id']=restaurant_data['restaurant_id']
        print("ID",session['restaurant_id'])
    return render_template("details.html",restaurant=restaurant)

@app.route("/findTable")
def findTable():
    return render_template("table.html")

@app.route("/bookTable",methods=['POST'])
def bookTable():
    #check for number of tables
    mysql= connectToMySQL('restaurants')
    query="SELECT table_nr FROM restaurant WHERE restaurant.restaurant_id=%(r_id)s"
    data={
        'r_id':session['restaurant_id']
    }
    result=mysql.query_db(query,data)
    if result:
        result_data=result[0]
        if result_data['table_nr'] > 0:
            mysql=connectToMySQL('restaurants')
            query="INSERT INTO restaurant_table(date_time,nr_of_persons,created_at,updated_at,restaurant_id,user_id) VALUES(%(date_time)s,%(nr_p)s,NOW(),NOW(),%(restaurant_id)s,%(user_id)s)"
            data={
                "date_time":request.form['datetime'],
                "nr_p":request.form['nr_persons'],
                "restaurant_id":session['restaurant_id'],
                "user_id":session['user_id']
            }
            table=mysql.query_db(query,data)

            #update database if there is a reservation
            mysql=connectToMySQL('restaurants')
            query="UPDATE restaurant SET table_nr = (table_nr-1) WHERE restaurant_id = %(r_id)s"
            data={
                'r_id':session['restaurant_id']
            }
            result=mysql.query_db(query,data)
            flash("Table Booked")
            return redirect("/findTable")
        else:
            flash("No table avalaible")
            return redirect("/findTable")
    

if __name__ == "__main__":
    app.run(debug=True)